Springer LNCS A4 manuscript source

Entry point: main.tex. All figures actually referenced by the manuscript are included.
llncs.cls and splncs04.bst are included unchanged from the original project.

Current validation engine: pdfLaTeX, MiKTeX 25.12. Run:
  pdflatex main.tex
  bibtex main
  pdflatex main.tex
  pdflatex main.tex

Alternative engine used for the earlier version: Tectonic 0.17.0 (XeTeX):
  tectonic --keep-logs --keep-intermediates main.tex

The source contains no engine-specific custom layout settings. Publisher installations
may use a different engine; pagination must be checked after any rebuild.
SOURCE_MANIFEST.json gives SHA256 for each manuscript dependency.
Author signature, registration/payment, and final OpenReview submission are separate.
